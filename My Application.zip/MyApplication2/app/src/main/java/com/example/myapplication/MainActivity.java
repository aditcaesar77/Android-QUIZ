package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    EditText  edtaktif, edquis, eduts, eduas, edakhir, edhuruf ;
    Button bthitung ;
    Double vtugas, vhadir, vuts, vuas, vakhir ;
    String vhuruf ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtaktif = (EditText) findViewById(R.id.edaktif);
        edquis = (EditText) findViewById(R.id.edquis);
        eduts = (EditText) findViewById(R.id.eduts);
        eduas = (EditText) findViewById(R.id.eduas);
        edakhir = (EditText) findViewById(R.id.edakhir);
        edhuruf = (EditText) findViewById(R.id.edhuruf);
        bthitung = (Button) findViewById(R.id.bthitung);
    }

    public void hitung(View view){
        vtugas = Double.parseDouble(edtaktif.getText().toString());
        vhadir = Double.parseDouble(edquis.getText().toString());
        vuts = Double.parseDouble(eduts.getText().toString());
        vuas = Double.parseDouble(eduas.getText().toString());


        vakhir = (0.1 * vhadir) + (0.1 * vtugas) + (0.35 * vuts) + (0.45 * vuas);

        if (vakhir >=85 && vakhir <=100){
            vhuruf="A";
        }
        else if (vakhir >=75 && vakhir <=85){
            vhuruf="B";
        }
        else if (vakhir >=65 && vakhir <=75){
            vhuruf="C";
        }
        else {
            vhuruf="Tidak Lulus";
        }
        edakhir.setText(""+vakhir);
        edhuruf.setText(""+vhuruf);
    }
}